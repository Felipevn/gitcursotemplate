# Projeto de exemplo - Curso Git

Projeto fictício e não funcional criado para demonstrar os funcionamentos do controle de versão usando um repositório remoto. Os arquivos usados para demonstração são referentes a um projeto Web disponível no site [startbootstrap.com](https://startbootstrap.com/themes/creative/).

### Conteúdo do curso
O conteúdo do curso cobre desde os conceitos teóricos iniciais para o entendimento de como a ferramenta funciona e a partir dos conhecimentos teóricos, exercícios e exemplos práticos são feitos para fixar o conhecimento.

- Tópicos do curso podem ser consultados neste [link](http://devmasterteam.com/Curso/Git).
- Aulas disponíveis na plataforma [Udemy](https://www.udemy.com/git-completo-do-basico-ao-avancado/?couponCode=AULABONUS).

**DevMasterTeam**